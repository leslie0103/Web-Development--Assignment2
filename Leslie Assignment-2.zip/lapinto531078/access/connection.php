<?php
$servername = 'localhost';
    $username = 'lapinto';
    $password = '531078';
    $dbname = "lapinto";
    $con=mysqli_connect($servername,$username,$password,$dbname);


if(!$con)
{
    echo "DB Connection error";
}
?>
